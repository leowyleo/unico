# Unico App Icon

已按 macOS / Mac App Store 图标资源整理完成。

- `Unico-AppStore-1024.png`：1024 × 1024、sRGB、无 Alpha 通道，可作为 App Store 大图标。
- `AppIcon.appiconset/`：可直接放入 Xcode 的 `Assets.xcassets`，包含 16–1024 px 的标准 macOS 槽位和 `Contents.json`。
- `PNG/`：独立的 16、32、64、128、256、512、1024 px PNG。
- `Unico.icns`：多分辨率 macOS 图标文件。

图标已裁掉原图四周无关留白；圆角与白色底板属于图标设计本身，并非额外画布边框。
